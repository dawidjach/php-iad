<?php 
require_once( '../maria_dawid_wassili/includes/functions.inc.php' );
set_exception_handler('exceptionHandler');
set_error_handler('errorHandler');
?>